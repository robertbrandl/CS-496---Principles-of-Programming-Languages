(*Robert Brandl
I pledge my honor that I have abided by the Stevens Honor System.*)
open Ast
open Ds
let rec apply_proc : exp_val -> exp_val -> exp_val ea_result =
  fun f a ->
  match f with
  | ProcVal (id,body,env) ->
    return env >>+
    extend_env id a >>+
    eval_expr body
  | _ -> error "apply_proc: Not a procVal"
and
 eval_expr : expr -> exp_val ea_result = fun e ->
  match e with
  | Int(n) ->
    return @@ NumVal n
  | Var(id) ->
    apply_env id
  | Add(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1+n2)
  | Sub(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1-n2)
  | Mul(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    return @@ NumVal (n1*n2)
  | Div(e1,e2) ->
    eval_expr e1 >>=
    int_of_numVal >>= fun n1 ->
    eval_expr e2 >>=
    int_of_numVal >>= fun n2 ->
    if n2==0
    then error "Division by zero"
    else return @@ NumVal (n1/n2)
  | Let(id,def,body) ->
    eval_expr def >>=
    extend_env id >>+
    eval_expr body
  | ITE(e1,e2,e3) ->
    eval_expr e1 >>=
    bool_of_boolVal >>= fun b ->
    if b
    then eval_expr e2
    else eval_expr e3
  | IsZero(e) ->
    eval_expr e >>=
    int_of_numVal >>= fun n ->
    return @@ BoolVal (n = 0)
  | Proc(id,e)  ->
    lookup_env >>= fun en ->
    return (ProcVal(id,e,en))
  | App(e1,e2)  ->
    eval_expr e1 >>= fun v1 ->
    eval_expr e2 >>= fun v2 ->
    apply_proc v1 v2
  | Abs(e1)      ->
    eval_expr e1  >>=
    int_of_numVal >>= fun n ->
    return @@ NumVal (abs n)
  | Cons(e1, e2) -> 
    eval_expr e1 >>= fun v1 ->
    eval_expr e2 >>= 
    list_of_listVal >>= fun v2 ->
    return @@ ListVal(v1 :: (v2))
  | Hd(e1) ->
    eval_expr e1 >>=
    list_of_listVal >>= fun n ->
    return @@ List.hd (n)
  | Tl(e1) ->  
    eval_expr e1 >>=
    list_of_listVal >>= fun n ->
    return @@ ListVal(List.tl (n))
  | Record(fs) -> let y = fun x -> eval_expr x >>= fun x -> return x in
    let z = List.map (fun (_,e) -> (y e)) fs in
    sequence z >>= fun v ->
    let rec func: string list -> exp_val list -> (string*exp_val) list =
      fun x y ->
     match x with
     |[] -> []
     |h::t -> (h, List.hd y) :: func t (List.tl y)
    in
    let strlist = List.map (fun (id,_) -> id) fs in
    let d = func strlist v in
    if duplicates strlist then error "Record: duplicate fields" else
    return @@ RecordVal(d)
  | Proj(e,id) -> 
    eval_expr e >>=
    record_of_recordVal >>= fun recv ->
    let rec findfield =
    fun x ->
    match x with 
    | [] -> error "Proj: field does not exist"
    | h::t -> 
    if (fst h) = id 
    then return @@ snd h
    else findfield t
    in findfield recv
  | Empty(e1)  ->
    eval_expr e1 >>=
    tree_of_treeVal >>= fun x ->
    if x = Empty
     then return @@ BoolVal true 
     else return @@ BoolVal false
  | EmptyList ->  return @@ ListVal([])
  | EmptyTree ->  return @@ TreeVal Empty
  | Node(e1,lte,rte) -> 
    eval_expr e1 >>= fun data ->
    eval_expr lte >>=
    tree_of_treeVal >>= fun lt ->
    eval_expr rte >>=
    tree_of_treeVal >>= fun rt ->
    return @@ TreeVal(Node(data,lt,rt))
  | CaseT(target,emptycase,id1,id2,id3,nodecase) ->
    eval_expr target >>=
    tree_of_treeVal >>= fun tar ->
    (match tar with
    | Empty -> eval_expr emptycase
    | Node(data, lt, rt) -> 
    (extend_env id1 data >>+ 
    extend_env id2 (TreeVal lt) >>+
    extend_env id3 (TreeVal rt) >>+
    eval_expr nodecase))
  | Tuple(es) -> let y = fun x -> eval_expr x >>= fun x -> return x in
    let z = (List.map (y) es) in
    sequence z >>= fun v ->
    return @@ TupleVal(v)
  | Untuple(ids,e1,e2) ->
    eval_expr e1 >>=
    tuple_of_tupleVal >>= fun tup -> 
    let rec f=
    fun idlist tupl ->
    match idlist with
    | [] -> eval_expr e2
    | h::t -> extend_env h (List.hd tupl) >>+ f t (List.tl tupl)
    in
    f ids tup 
  | _ -> failwith "not implemented"



(***********************************************************************)
(* Everything above this is essentially the same as we saw in lecture. *)
(***********************************************************************)

(* Parse a string into an ast *)





let parse s =
  let lexbuf = Lexing.from_string s in
  let ast = Parser.prog Lexer.read lexbuf in
  ast

let lexer s =
  let lexbuf = Lexing.from_string s
  in Lexer.read lexbuf


(* Interpret an expression *)
let interp (e:string) : exp_val result =
  let c = e |> parse |> eval_expr
  in run c

 let e1 = "let t = node ( emptylist ,
  node ( cons (5 , cons (2 , cons (1 , emptylist ))) ,
  emptytree ,
  node ( emptylist ,
  emptytree ,
  emptytree
  )
  ),
  node ( tl ( cons (5 , emptylist )) ,
  node ( cons (10 , cons (9 , cons (8 , emptylist ))) ,
  emptytree ,
  emptytree
  ),
  node ( emptylist ,
  node ( cons (9 , emptylist ),
  emptytree ,
  emptytree
  ),
  emptytree
  )
  )
  )
  in
  caseT t of {
  emptytree -> 10 ,
  node (a ,l ,r) ->
  if empty ?( a)
  then caseT l of {
  emptytree -> 21 ,
  node (b , ll , rr ) -> if empty ?( b)
  then 4
  else if zero ?( hd (b ))
  then 22
  else 99
  }
  else 5
  }"